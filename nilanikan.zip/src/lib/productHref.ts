// تا همه‌چیز یکجا مدیریت شود، از urls.ts خروجی می‌گیریم
export {
  productHref,
  slugify,
  extractShortIdFromSlug,
  getProductBySlug,
} from "./urls";
