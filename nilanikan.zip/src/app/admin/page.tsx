// src/app/admin/page.tsx
import AdminDashboard from "./AdminDashboard";

export default function Page() {
  return <AdminDashboard />;
}
