// src/components/ProductCard.tsx
"use client";
import Link from "next/link";
import * as React from "react";
import { useCart } from "../context/CartContext";  // اضافه کردن import برای استفاده از CartContext

export type ProductCardProps = {
  id: string;
  title: string;
  slug: string;
  price: number;
  priceBefore?: number | null;
  images?: { src: string; alt?: string }[] | any;
  className?: string; // برای استفاده داخل کاروسل
  showAddButton?: boolean; // در صورت نیاز دکمه نمایش داده شود
};

export default function ProductCard({
  id,
  title,
  slug,
  price,
  priceBefore,
  images,
  className = "",
  showAddButton = false,
}: ProductCardProps) {
  const { addToCart } = useCart();  // استفاده از hook برای دسترسی به وضعیت سبد خرید

  // حالت‌های مختلفی که بعضی بک‌اندها برای تصاویر برمی‌گردانند را هندل می‌کنیم
  const firstImg =
    Array.isArray(images)
      ? images[0]
      : images && typeof images === "object"
      ? images[0] ?? images
      : null;

  const imgSrc =
    (typeof firstImg === "string" ? firstImg : firstImg?.src) || "/demo/p1.jpg";
  const imgAlt =
    (typeof firstImg === "object" && (firstImg?.alt as string)) || title || "";

  const hasDiscount =
    typeof priceBefore === "number" &&
    priceBefore > 0 &&
    priceBefore > price;

  const discountPercent = hasDiscount
    ? Math.max(1, Math.round(((priceBefore as number) - price) / (priceBefore as number) * 100))
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // لینک را باز نکن
    addToCart({ id, title, price, quantity: 1 }); // افزودن محصول به سبد خرید
  };

  return (
    <Link
      href={`/product/${slug}`}
      dir="rtl"
      className={`group rounded-2xl overflow-hidden border border-pink-300/60 bg-white hover:shadow-sm transition-shadow ${className}`}
      aria-label={title}
    >
      <div className="relative aspect-[1/1] bg-white">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          alt={imgAlt}
          src={imgSrc}
          loading="lazy"
          className="object-contain w-full h-full p-3"
          draggable={false}
        />

        {hasDiscount && (
          <span className="absolute top-2 right-2 text-xs font-bold bg-pink-600 text-white px-2 py-1 rounded-full">
            {discountPercent}٪
          </span>
        )}
      </div>

      <div className="p-3 grid gap-1">
        <h3 className="text-sm leading-6 line-clamp-2">{title}</h3>

        <div className="flex items-end justify-between mt-1">
          {hasDiscount ? (
            <span className="inline-flex items-center rounded-md bg-pink-600 text-white text-xs px-2 py-1">
              {discountPercent}٪
            </span>
          ) : (
            <span />
          )}

          <div className="text-left">
            {hasDiscount && (
              <div className="text-[11px] text-gray-400 line-through">
                {(priceBefore as number).toLocaleString("fa-IR")} تومان
              </div>
            )}
            <div className="text-sm font-semibold text-gray-800">
              {price.toLocaleString("fa-IR")} تومان
            </div>
          </div>
        </div>

        {showAddButton && (
          <button
            type="button"
            className="mt-2 w-full border rounded-xl py-2 text-sm hover:bg-emerald-600 hover:text-white transition"
            onClick={handleAddToCart}  // افزودن محصول به سبد خرید
          >
            افزودن به سبد
          </button>
        )}
      </div>
    </Link>
  );
}
